import { Chart } from "./components/line-chart-1/Chart";

function App() {
  return <Chart />;
}

export default App;
